package ie.gmit.dip;

import java.io.IOException;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Scanner;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;

public class Image {
	public static String filename = "gmit-rgb.png";
	Kernel K = new Kernel();
	Scanner scan = new Scanner(System.in);
	
	void selector(double arr[][]) throws IOException
	{
		String img1 ="gmit-rgb.png";
		String img2 ="gmit-gs.png";
		String img3 ="bridge-rgb.png";
		String img4 ="bridge-gs.png";

		System.out.println("Input 1: To Select [gmit-rgb.png] :- ");
		System.out.println("Input 2: To Select [gmit-gs.png] :- ");
		System.out.println("Input 3: To Select [bridge-rgb.png] :- ");
		System.out.println("Input 4: To Select [bridge-gs.png] :- ");
		
		while (!scan.hasNextInt() ) {
		      System.out.println("Input is not a number.");
		      scan.nextLine();
		    }
		int x = scan.nextInt();
		System.out.println(x);
		if (x>=1 && x<5)
		{
			if(x==1)
			{
				filename=img1;
				ImageRender(arr);
			}
			if(x==2)
			{
				filename=img2;
				ImageRender(arr);
			}
			if(x==3)
			{
				filename=img3;
				ImageRender(arr);
			}
			if(x==4)
			{
				filename=img4;
				ImageRender(arr);
			}
		}
		else
			System.out.println("Wrong Selection - Image not found...");
	}
	
	
	void ImageRender(double arr[][]) throws IOException
	{
		System.out.print("Kernel Order: 3");
		//int order = Integer.parseInt(reader.readLine());
		
		//float[][] kernel = new float[order][order];
		int len = arr.length;
		float sum = 0.0f;
		float factor = 1.0f;
		final double[][] kernel = arr;
		
		System.out.println("\nThe Kernel Matrix is:\n"); //Printing the Convolution Matrix//
		for(int i=0; i < len; i++)
		{
			for(int j=0; j < len; j++)
			{
				System.out.print("\t"+kernel[i][j]);
				sum += kernel[i][j];
			}
			System.out.println();
		}
		System.out.println("\nThe sum of matrix elements is: "+sum);
		//MF is the Intensity of the Filter - Higher Value will cause of more effect//
		System.out.println("MF should be near to: "+(1/sum));
		System.out.print("Input Multipling Factor(Intensity of Filter): ");
		factor = scan.nextFloat();
		BufferedImage input,output;
		
		input = ImageIO.read(new File(filename));
		int WIDTH = input.getWidth();
		int HEIGHT = input.getHeight();
		
		output = new BufferedImage(WIDTH, HEIGHT, input.getType());
		System.out.println("Rendering the image/Workin on Filter...");
		for(int x=0;x<WIDTH;x++)
		{
			for(int y=0;y<HEIGHT;y++)
			{
				float red=0f,green=0f,blue=0f;
				for(int i=0;i<len;i++)
				{
					for(int j=0;j<len;j++)
					{
						// Calculating X and Y coordinates of the pixel to be multiplied with current kernel element
						// In case of edges of image the '% WIDTH' wraps the image and the pixel from opposite edge is used
						int imageX = (x - len / 2 + i + WIDTH) % WIDTH; 
						int imageY = (y - len / 2 + j + HEIGHT) % HEIGHT; 
						
						int RGB = input.getRGB(imageX,imageY);
						int R = (RGB >> 16) & 0xff; // Red Value
						int G = (RGB >> 8) & 0xff;	// Green Value
						int B = (RGB) & 0xff;		// Blue Value
						
						// The RGB is multiplied with current kernel element and added on to the variables red, blue and green
						red += (R*kernel[i][j]);
						green += (G*kernel[i][j]);
						blue += (B*kernel[i][j]);
					}
				}
				int outR, outG, outB;
				// The value is truncated to 0 and 255 if it goes beyond
				outR = Math.min(Math.max((int)(red*factor),0),255);
				outG = Math.min(Math.max((int)(green*factor),0),255);
				outB = Math.min(Math.max((int)(blue*factor),0),255);
				// Pixel is written to output image
				output.setRGB(x,y,new Color(outR,outG,outB).getRGB());
			}
		}
		
		System.out.print("Save output file as-> ");
		scan.nextLine();
		String outputfname = scan.nextLine();
		ImageIO.write(output,"PNG", new File("output_"+outputfname+".png"));
		System.out.print("File saved as-> "+outputfname+".png");
		
		
	}
}
