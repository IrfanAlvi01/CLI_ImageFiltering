package ie.gmit.dip;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Runner {
	
	public static void main(String[] args) throws Exception {

		System.out.println(ConsoleColour.BLUE_BRIGHT);
		System.out.println("***************************************************");
		System.out.println("* GMIT - Dept. Computer Science & Applied Physics *");
		System.out.println("*                                                 *");
		System.out.println("*           Image Filtering System V0.1           *");
		System.out.println("*     H.Dip in Science (Software Development)     *");		
		System.out.println("*                                                 *");
		System.out.println("***************************************************\n");
		
		System.out.println("<---------------------How to Use--------------------->");
		System.out.println("Info-> Select the Filter First-");
		System.out.println("Info-> Select the Image from provided list-");
		System.out.println("Info-> Input MF (Intensity of the Filter)-");
		System.out.println("Info-> You will see suggested MF as well-");
		System.out.println("Info-> Input a MF value near to suggested value-");
		System.out.println("Info-> Then finally Type a name for the ouput image-");
		System.out.println("Info-> You will find that output image in project Dir-");
		System.out.println("<---------------------------------------------------->\n");
		Menu m =new Menu();
		m.RunMenu();

	}
}