package ie.gmit.dip;

import java.io.IOException;
import java.util.Scanner;

public class Menu {
	Kernel K = new Kernel();
	Scanner scan = new Scanner(System.in);
	Image I = new Image();
	int choice = 1;
	boolean trigger = false;

  	void RunMenu() throws IOException
  	{

  	  	do {
  		System.out.println("Input 1: For IDENTITY Filter:- "); 
  		System.out.println("Input 2: For EDGE DETECTION-I Filter:- ");
  		System.out.println("Input 3: For EDGE DETECTION-II Filter:- ");
  		System.out.println("Input 4: For LAPLACIAN Filter:- ");
  		System.out.println("Input 5: For SHARPEN Filter:- ");
  		System.out.println("Input 6: For VERTICAL LINES Filter:- ");
  		System.out.println("Input 7: For HORIZONTAL LINES Filter:- ");
  		System.out.println("Input 8: For DIAGONAL 45 LINES Filter:- ");
  		System.out.println("Input 9: For BLUR Filter:- ");
  		System.out.println("Input 10: For BOX_BLUR Filter:- ");
  		System.out.println("Input 11: For MOTION_BLUR Filter:- ");
  		System.out.println("Input 12: For GAUSSIAN_BLUR Filter:- ");
  		System.out.println("Input 13: For SOBEL_HORIZONTAL Filter:- ");
  		System.out.println("Input 14: For SOBEL_VERTICAL Filter:- ");
  		System.out.println("Input 15: For MEAN Filter:- ");
  		System.out.println("Input  0: For QUITING Program:- ");
  		System.out.println("<---Select Option [#]--->\n");
  		while (!scan.hasNextInt() ) {
  		      System.out.println("Input is not a number.");
  		      scan.nextLine();
  		    }
  		choice = scan.nextInt();
  		
  			switch(choice)
  			{
  				case 1:
  				{
  					I.selector(K.IDENTITY);
  					break;
  				}
  				case 2:
  				{
  					I.selector(K.EDGE_DETECTION_1);
  					break;
  				}
  				case 3:
  				{
  					I.selector(K.EDGE_DETECTION_2);
  					break;
  				}
  				case 4:
  				{
  					I.selector(K.LAPLACIAN);
  					break;
  				}
  				case 5:
  				{
  					I.selector(K.SHARPEN);
  					break;
  				}
  				case 6:
  				{
  					I.selector(K.VERTICAL_LINES);
  					break;
  				}
  				case 7:
  				{
  					I.selector(K.HORIZONTAL_LINES);
  					break;
  				}
  				case 8:
  				{
  					I.selector(K.DIAGONAL_45_LINES);
  					break;
  				}
  				case 9:
  				{
  					I.selector(K.BLUR_1);
  					break;
  				}
  				case 10:
  				{
  					I.selector(K.BOX_BLUR);
  					break;
  				}
  				case 11:
  				{
  					I.selector(K.MOTION_BLUR);
  					break;
  				}
  				case 12:
  				{
  					I.selector(K.GAUSSIAN_BLUR);
  					break;
  				}
  				case 13:
  				{
  					I.selector(K.SOBEL_HORIZONTAL);
  					break;
  				}
  				case 14:
  				{
  					I.selector(K.SOBEL_VERTICAL);
  					break;
  				}
  				case 15:
  				{
  					I.selector(K.MEAN);
  					break;
  				}
  				case 0:
  				{
  					System.out.println("You Successfully Quitted the Program:");
  					trigger = true;
  					break;
  				}
  				default:
  				{
  					System.out.println("Please Select the right Filter Again: ");
  					break;
  				}
  			}
  		
  	  	}while(trigger!=true);

  	}
	
}

